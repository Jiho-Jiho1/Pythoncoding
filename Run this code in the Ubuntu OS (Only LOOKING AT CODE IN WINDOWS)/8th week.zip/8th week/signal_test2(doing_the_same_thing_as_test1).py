import signal
import time
def handler(signum, frame):
    print("Handler is activated")
signal.signal(signal.SIGALRM, handler)
signal.setitimer(signal.ITIMER_REAL, 0.1, 1) #After 0.1 seconds, a sigalarm happens every one second.
while True:
    time.sleep(0.5)
    print("Infinity loop has been activated")