from cs1robots import *
create_world()
game=Robot()
enemy=Robot(avenue=10, street=10, orientation='W' ,color="yellow")
#------------------------------------------
def safe_move():
    if game.front_is_clear():
        game.move()
#------------------------------------------
scene=get_scene()
while True:
    e=scene.wait()
    if e==None:
        break
#From here the Robot will get keyboard inputs.
    elif e.getDescription()=="keyboard":
        key=e.getKey()
        if key=="w":
            game.set_dir("N")
            safe_move()
        elif key=="a":
            game.set_dir("W")
            safe_move()
        elif key=="s":
            game.set_dir("S")
            safe_move()
        elif key=="d":
            game.set_dir("E")
            safe_move()
        elif key==" ":
            if game.on_beeper():
                game.pick_beeper()
#----------------------------------------------
#To be continued... (On next Coding Class)
