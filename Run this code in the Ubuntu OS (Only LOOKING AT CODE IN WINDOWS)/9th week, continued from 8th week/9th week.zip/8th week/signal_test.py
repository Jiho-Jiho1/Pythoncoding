import signal
import time
def handler(signum, frame):
    print("Handler is activated")
    signal.alarm(1)
signal.signal(signal.SIGALRM, handler)
signal.alarm(1)
while True:
    time.sleep(0.5)
    print("Infinity loop has been activated")