from cs1robots import *
import signal
import sys
import random
create_world()
game=Robot()
enemy=Robot(avenue=10, street=10, orientation='W' ,color="yellow")
#------------------------------------------
def handler(*argv):
    #making random beepers
    if random.random()<0.3:
        add_beeper(random.randint(1, 10), random.randint(1, 10))


    #move enemy
    game_get_x, game_get_y=game.get_pos()
    enemy_get_x, enemy_get_y=enemy.get_pos()

    if game_get_x>enemy_get_x:
        enemy.set_dir("E")
        enemy.move()
    
    elif enemy_get_x>game_get_x:
        enemy.set_dir("W")
        enemy.move()

    else:#if game get x=enemy get x
        if game_get_y>enemy_get_y:
            enemy.set_dir("N")
            enemy.move()

        elif game_get_y<enemy_get_y:
            enemy.set_dir("S")
            enemy.move()

        else:#same position
            print("You Lose!")
            signal.setitimer(signal.ITIMER_REAL, 0, 0)#end signal
            sys.exit()
    #enemy eats near beepers
    while enemy.on_beeper():
        enemy.pick_beeper()

signal.signal(signal.SIGALRM, handler)
signal.setitimer(signal.ITIMER_REAL, 3, 1)

def safe_move():
    if game.front_is_clear():
        game.move()
#------------------------------------------
beeper_count = 0

scene=get_scene()
while True:
    e=scene.wait()
    if e==None:
        break
#From here the Robot will get keyboard inputs.
    elif e.getDescription()=="keyboard":
        key=e.getKey()
        if key=="w":
            game.set_dir("N")
            safe_move()
        elif key=="a":
            game.set_dir("W")
            safe_move()
        elif key=="s":
            game.set_dir("S")
            safe_move()
        elif key=="d":
            game.set_dir("E")
            safe_move()
        elif key==" ":
            if game.on_beeper():
                game.pick_beeper()
                beeper_count += 1
    if beeper_count == 3:
        print("Congrats! You Won!")
        signal.setitimer(signal.ITIMER_REAL, 0, 0)#end signal
        sys.exit()
#----------------------------------------------
#To be continued... (On next Coding Class)
#Next Coding Class...

